/**
 * 数据统计页面增强（后端是编译产物 umi/antd，这里运行时注入）：
 * - 蜘蛛分析 / 流量分析 / 收录分析：顶部加「最近 7 天 / 30 天 / 90 天」切换，
 *   通过拦截 statistic 接口请求把 `days` 参数带上，图表随窗口变化；
 * - 访问记录：加关键词搜索框（`q` 参数）与「导出 CSV」按钮；
 * - 收录分析 / 收录记录：加「立即更新收录」按钮（走手动采集接口）。
 *
 * 原理：与 header-menu-entry.js 同一套注入方式（MutationObserver 保持存在）；
 * 接口参数通过 hook XMLHttpRequest/fetch 在请求发出前改写 URL，组件无感知。
 */
(function () {
    'use strict';

    if (window.location.pathname.indexOf('/system') !== 0) {
        return;
    }
    if (/\/system\/(login|install)/.test(window.location.pathname)) {
        return;
    }

    var BAR_ID = 'rustcms-stat-toolbar';
    var STYLE_ID = 'rustcms-stat-toolbar-style';
    var DAYS_KEY = 'rustcms-stat-days';
    var Q_KEY = 'rustcms-stat-q';

    // 与 SPA 请求拦截器同口径：读 `anqi-adminToken` 令牌放 `admin` 请求头
    function adminToken() {
        try {
            var raw = window.sessionStorage.getItem('anqi-adminToken')
                || window.localStorage.getItem('anqi-adminToken') || '';
            if (!raw) {
                return '';
            }
            try {
                var v = JSON.parse(raw);
                return typeof v === 'string' ? v : '';
            } catch (e) {
                return raw;
            }
        } catch (e) {
            return '';
        }
    }

    function days() {
        var v = parseInt(window.localStorage.getItem(DAYS_KEY) || '30', 10);
        return [7, 30, 90].indexOf(v) >= 0 ? v : 30;
    }

    function keyword() {
        try {
            return (window.localStorage.getItem(Q_KEY) || '').trim();
        } catch (e) {
            return '';
        }
    }

    // ---------------------------------------------------------------------------
    // 请求改写：给 statistic 接口附加 days / q 参数（XMLHttpRequest 与 fetch 都拦）
    // ---------------------------------------------------------------------------

    function rewriteApiUrl(url) {
        if (!url || url.indexOf('/system/api/statistic') === -1) {
            return url;
        }
        try {
            var u = new URL(url, window.location.origin);
            var path = u.pathname;
            var isChart = /\/system\/api\/statistic\/(spider|traffic|include)$/.test(path);
            var isDetail = path === '/system/api/statistic/detail';
            if (!isChart && !isDetail) {
                return url;
            }
            if (isChart) {
                u.searchParams.set('days', String(days()));
            }
            if (isDetail) {
                var q = keyword();
                if (q) {
                    u.searchParams.set('q', q);
                } else {
                    u.searchParams.delete('q');
                }
            }
            return u.toString();
        } catch (e) {
            return url;
        }
    }

    function hookRequests() {
        if (window.__rustcmsStatHooked__) {
            return;
        }
        window.__rustcmsStatHooked__ = true;

        var origOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (method, url) {
            var rest = Array.prototype.slice.call(arguments, 2);
            return origOpen.apply(this, [method, rewriteApiUrl(url)].concat(rest));
        };

        var origFetch = window.fetch;
        window.fetch = function (input, init) {
            try {
                if (typeof input === 'string') {
                    input = rewriteApiUrl(input);
                } else if (input && input.url) {
                    input = new Request(rewriteApiUrl(input.url), input);
                }
            } catch (e) { /* 保持原请求 */ }
            return origFetch.call(this, input, init);
        };
    }

    // ---------------------------------------------------------------------------
    // 工具条
    // ---------------------------------------------------------------------------

    function injectStyle() {
        if (document.getElementById(STYLE_ID)) {
            return;
        }
        var style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = [
            '#rustcms-stat-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:12px;margin:0 0 16px;padding:10px 16px;background:#fff;border:1px solid #f0f0f0;border-radius:6px;font-size:14px}',
            '#rustcms-stat-toolbar .rustcms-stat-label{color:rgba(0,0,0,.45)}',
            '#rustcms-stat-toolbar button{border:1px solid #d9d9d9;background:#fff;color:rgba(0,0,0,.65);border-radius:4px;padding:3px 12px;font:inherit;cursor:pointer;line-height:22px}',
            '#rustcms-stat-toolbar button:hover{color:#1677ff;border-color:#1677ff}',
            '#rustcms-stat-toolbar button.active{color:#fff;background:#1677ff;border-color:#1677ff}',
            '#rustcms-stat-toolbar button:disabled{color:rgba(0,0,0,.35);cursor:not-allowed;background:#f5f5f5;border-color:#d9d9d9}',
            '#rustcms-stat-toolbar input{border:1px solid #d9d9d9;border-radius:4px;padding:3px 10px;font:inherit;line-height:22px;width:220px;outline:none}',
            '#rustcms-stat-toolbar input:focus{border-color:#1677ff}'
        ].join('');
        document.head.appendChild(style);
    }

    function currentDaysPage() {
        return /\/system\/statistic\/(spider|traffic|includes)\/?$/.test(window.location.pathname);
    }

    function currentDetailPage() {
        return /\/system\/statistic\/detail\/?$/.test(window.location.pathname);
    }

    function currentIncludePage() {
        return /\/system\/statistic\/(includes|include\/detail)\/?$/.test(window.location.pathname);
    }

    function buildToolbar() {
        var bar = document.createElement('div');
        bar.id = BAR_ID;
        var parts = [];

        if (currentDaysPage()) {
            var active = days();
            parts.push('<span class="rustcms-stat-label">统计范围：</span>');
            [7, 30, 90].forEach(function (d) {
                parts.push('<button type="button" data-days="' + d + '" class="'
                    + (d === active ? 'active' : '') + '">最近 ' + d + ' 天</button>');
            });
        }

        if (currentDetailPage()) {
            var today = new Date();
            var stamp = today.getFullYear()
                + ('0' + (today.getMonth() + 1)).slice(-2)
                + ('0' + today.getDate()).slice(-2);
            parts.push('<span class="rustcms-stat-label">关键词：</span>');
            parts.push('<input type="text" id="rustcms-stat-q" placeholder="按地址/IP/UA/设备筛选" value="'
                + keyword().replace(/"/g, '&quot;') + '">');
            parts.push('<button type="button" id="rustcms-stat-q-apply">搜索</button>');
            parts.push('<span class="rustcms-stat-label">导出日期：</span>');
            parts.push('<input type="text" id="rustcms-stat-export-date" placeholder="YYYYMMDD" value="'
                + stamp + '" maxlength="8" style="width:110px">');
            parts.push('<button type="button" id="rustcms-stat-export">导出 CSV</button>');
        }

        if (currentIncludePage()) {
            parts.push('<span class="rustcms-stat-label">收录数据每天 8 点自动采集，也可手动刷新：</span>');
            parts.push('<button type="button" id="rustcms-stat-collect">立即更新收录</button>');
        }

        bar.innerHTML = parts.join('');
        return bar;
    }

    function exportCsv() {
        var date = (document.getElementById('rustcms-stat-export-date') || {}).value || '';
        if (date && !/^\d{8}$/.test(date)) {
            window.alert('导出日期请填写 8 位数字（如 20261112）');
            return;
        }
        var params = new URLSearchParams();
        if (date) {
            params.set('date', date);
        }
        var q = keyword();
        if (q) {
            params.set('q', q);
        }
        var button = document.getElementById('rustcms-stat-export');
        if (button) {
            button.disabled = true;
        }
        fetch('/system/api/statistic/detail/export?' + params.toString(), {
            credentials: 'same-origin',
            headers: { admin: adminToken() }
        }).then(function (res) {
            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }
            return res.blob();
        }).then(function (blob) {
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'statistic-detail-' + (date || 'all') + '.csv';
            document.body.appendChild(a);
            a.click();
            setTimeout(function () {
                URL.revokeObjectURL(a.href);
                a.remove();
            }, 1000);
        }).catch(function () {
            window.alert('导出失败，请稍后重试');
        }).finally(function () {
            if (button) {
                button.disabled = false;
            }
        });
    }

    function collectInclude() {
        var button = document.getElementById('rustcms-stat-collect');
        if (!button || button.disabled) {
            return;
        }
        button.disabled = true;
        button.textContent = '采集中…（约 5 秒）';
        fetch('/system/api/statistic/include/collect', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', admin: adminToken() },
            body: '{}'
        }).then(function (res) {
            return res.json();
        }).then(function (body) {
            if (body && body.code === 0) {
                window.alert('收录量已更新，页面即将刷新');
                window.location.reload();
            } else {
                window.alert('采集失败：' + ((body && body.msg) || '未知错误'));
                button.disabled = false;
                button.textContent = '立即更新收录';
            }
        }).catch(function () {
            window.alert('采集请求失败，请稍后重试');
            button.disabled = false;
            button.textContent = '立即更新收录';
        });
    }

    function bindToolbar(bar) {
        bar.querySelectorAll('button[data-days]').forEach(function (button) {
            button.addEventListener('click', function () {
                window.localStorage.setItem(DAYS_KEY, button.getAttribute('data-days'));
                window.location.reload();
            });
        });
        var apply = bar.querySelector('#rustcms-stat-q-apply');
        if (apply) {
            apply.addEventListener('click', function () {
                var input = bar.querySelector('#rustcms-stat-q');
                var value = (input ? input.value : '').trim();
                if (value) {
                    window.localStorage.setItem(Q_KEY, value);
                } else {
                    window.localStorage.removeItem(Q_KEY);
                }
                window.location.reload();
            });
        }
        var qInput = bar.querySelector('#rustcms-stat-q');
        if (qInput) {
            qInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    var button = bar.querySelector('#rustcms-stat-q-apply');
                    if (button) {
                        button.click();
                    }
                }
            });
        }
        var exportButton = bar.querySelector('#rustcms-stat-export');
        if (exportButton) {
            exportButton.addEventListener('click', exportCsv);
        }
        var collectButton = bar.querySelector('#rustcms-stat-collect');
        if (collectButton) {
            collectButton.addEventListener('click', collectInclude);
        }
    }

    function tryInject() {
        if (!currentDaysPage() && !currentDetailPage() && !currentIncludePage()) {
            return;
        }
        if (document.getElementById(BAR_ID)) {
            return;
        }
        var container = document.querySelector('.ant-pro-page-container-children-container')
            || document.querySelector('.ant-pro-grid-content-children');
        if (!container) {
            return;
        }
        injectStyle();
        var bar = buildToolbar();
        container.insertBefore(bar, container.firstChild);
        bindToolbar(bar);
    }

    function cleanup() {
        var bar = document.getElementById(BAR_ID);
        if (bar) {
            bar.remove();
        }
    }

    var lastPath = window.location.pathname;
    function boot() {
        hookRequests();
        tryInject();
        var observer = new MutationObserver(function () {
            if (window.location.pathname !== lastPath) {
                lastPath = window.location.pathname;
                cleanup();
            }
            tryInject();
        });
        observer.observe(document.body, { childList: true, subtree: true });
        setInterval(function () {
            if (window.location.pathname !== lastPath) {
                lastPath = window.location.pathname;
                cleanup();
            }
            tryInject();
        }, 1500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
